/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.quizlb151;

/**
 *
 * @author monst
 */
public class Letter {
    private char character;
    private boolean visible;
    private boolean showSpace;

    public Letter(char character, boolean visible, boolean showSpace) {
        this.character = character;
        this.visible = visible;
        this.showSpace = showSpace;
    }

    public char getCharacter() {
        return character;
    }

    public void setCharacter(char character) {
        this.character = character;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isShowSpace() {
        return showSpace;
    }

    public void setShowSpace(boolean showSpace) {
        this.showSpace = showSpace;
    }

    
    
}


