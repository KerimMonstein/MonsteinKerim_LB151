/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.quizlb151;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author monst
 */
@Entity
@Table(name = "spiele")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Spiele.findAll", query = "SELECT s FROM Spiele s"),
    @NamedQuery(name = "Spiele.findById", query = "SELECT s FROM Spiele s WHERE s.id = :id"),
    @NamedQuery(name = "Spiele.findBySpieler", query = "SELECT s FROM Spiele s WHERE s.spieler = :spieler"),
    @NamedQuery(name = "Spiele.findByStart", query = "SELECT s FROM Spiele s WHERE s.start = :start"),
    @NamedQuery(name = "Spiele.findByEnde", query = "SELECT s FROM Spiele s WHERE s.ende = :ende"),
    @NamedQuery(name = "Spiele.findByPunktzahl", query = "SELECT s FROM Spiele s WHERE s.punktzahl = :punktzahl")})
public class Spiele implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "spieler")
    private String spieler;
    @Basic(optional = false)
    @NotNull
    @Column(name = "start")
    @Temporal(TemporalType.TIMESTAMP)
    private Date start;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ende")
    @Temporal(TemporalType.TIMESTAMP)
    private Date ende;
    @Basic(optional = false)
    @NotNull
    @Column(name = "punktzahl")
    private int punktzahl;

    public Spiele() {
    }

    public Spiele(Integer id) {
        this.id = id;
    }

    public Spiele(Integer id, String spieler, Date start, Date ende, int punktzahl) {
        this.id = id;
        this.spieler = spieler;
        this.start = start;
        this.ende = ende;
        this.punktzahl = punktzahl;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSpieler() {
        return spieler;
    }

    public void setSpieler(String spieler) {
        this.spieler = spieler;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnde() {
        return ende;
    }

    public void setEnde(Date ende) {
        this.ende = ende;
    }

    public int getPunktzahl() {
        return punktzahl;
    }

    public void setPunktzahl(int punktzahl) {
        this.punktzahl = punktzahl;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Spiele)) {
            return false;
        }
        Spiele other = (Spiele) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.bbbaden.quizlb151.Spiele[ id=" + id + " ]";
    }
    
}
