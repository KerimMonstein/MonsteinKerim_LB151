/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.quizlb151;

/**
 *
 * @author monst
 */
public class Word {

    private Letter[] letters;
    private boolean vowelsVisible;

    public Word(String str) {
        letters = new Letter[str.length()];
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c == ' ') {
                letters[i] = new Letter(c, true, true);
            }
            else {
                letters[i] = new Letter(c, false, false);
            }
        }
    }

    public Letter[] getLetters() {
        return letters;
    }

    public void showLetter(char c) {
        for (Letter letter : letters) {
            if (letter.getCharacter() == c) {
                letter.setVisible(true);
            }
        }
    }

    public void showAllVowels() {
        for (Letter letter : letters) {
            if (isVowel(letter.getCharacter())) {
                letter.setVisible(true);
            }
        }
        vowelsVisible = true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Letter letter : letters) {
            if (letter.getCharacter() == ' ' || letter.isVisible()) {
                sb.append(letter.getCharacter());
            }
            else {
                sb.append('_');
            }
        }
        return sb.toString();
    }

    private boolean isVowel(char c) {
        return "AEIOUaeiou".indexOf(c) != -1;
    }

    public void setLetterVisible(int index, boolean visible) {
        if (index >= 0 && index < letters.length) {
            letters[index].setVisible(visible);
        }
    }

    public void setWordVisible() {
        for (Letter letter : letters) {
            letter.setVisible(true);
        }
    }

    public boolean isVowelsVisible() {
        return vowelsVisible;
    }

}
