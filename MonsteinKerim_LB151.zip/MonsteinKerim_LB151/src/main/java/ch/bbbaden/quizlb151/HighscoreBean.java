/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.quizlb151;

import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

/**
 *
 * @author monst
 */
@Named(value = "highscoreBean")
@SessionScoped  
public class HighscoreBean implements Serializable {

    private EntityManager em = Persistence.createEntityManagerFactory("ch.bbbaden_MonsteinKerim_LB151_war_1.0-SNAPSHOTPU").createEntityManager();

    public List<Highscoreliste> getHighscores() {
        List<Highscoreliste> highscores = em.createNamedQuery("Highscoreliste.findAll", Highscoreliste.class).getResultList();
        Collections.sort(highscores, new Comparator<Highscoreliste>() {
            @Override
            public int compare(Highscoreliste h1, Highscoreliste h2) {
                return h2.getGewinn() - h1.getGewinn();
            }
        });

        return highscores;
    }

}
