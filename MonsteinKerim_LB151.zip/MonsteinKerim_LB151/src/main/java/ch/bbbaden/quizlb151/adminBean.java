/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.quizlb151;

import java.io.Serializable;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author monst
 */
@Named(value = "adminBean")
@SessionScoped
public class adminBean implements Serializable  {

    private String name;
    private String password;
    
    
    
    public String login(){
        if(name.equals("admin") && password.equals("admin123")){
            return "/secured/adminInterface.xhtml?faces-redirect=true";
        }else{
            System.out.println(name + " " + password);
            return "index";
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}
