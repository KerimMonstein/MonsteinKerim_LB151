/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.quizlb151;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author monst
 */
@Entity
@Table(name = "highscoreliste")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Highscoreliste.findAll", query = "SELECT h FROM Highscoreliste h"),
    @NamedQuery(name = "Highscoreliste.findById", query = "SELECT h FROM Highscoreliste h WHERE h.id = :id"),
    @NamedQuery(name = "Highscoreliste.findByRang", query = "SELECT h FROM Highscoreliste h WHERE h.rang = :rang"),
    @NamedQuery(name = "Highscoreliste.findByName", query = "SELECT h FROM Highscoreliste h WHERE h.name = :name"),
    @NamedQuery(name = "Highscoreliste.findByStartZeit", query = "SELECT h FROM Highscoreliste h WHERE h.startZeit = :startZeit"),
    @NamedQuery(name = "Highscoreliste.findByEndZeit", query = "SELECT h FROM Highscoreliste h WHERE h.endZeit = :endZeit"),
    @NamedQuery(name = "Highscoreliste.findByGewinn", query = "SELECT h FROM Highscoreliste h WHERE h.gewinn = :gewinn")})
public class Highscoreliste implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Rang")
    private int rang;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "Name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Column(name = "StartZeit")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startZeit;
    @Basic(optional = false)
    @NotNull
    @Column(name = "EndZeit")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endZeit;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Gewinn")
    private int gewinn;

    public Highscoreliste() {
    }

    public Highscoreliste(Integer id) {
        this.id = id;
    }

    public Highscoreliste(Integer id, int rang, String name, Date startZeit, Date endZeit, int gewinn) {
        this.id = id;
        this.rang = rang;
        this.name = name;
        this.startZeit = startZeit;
        this.endZeit = endZeit;
        this.gewinn = gewinn;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getRang() {
        return rang;
    }

    public void setRang(int rang) {
        this.rang = rang;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getStartZeit() {
        return startZeit;
    }

    public void setStartZeit(Date startZeit) {
        this.startZeit = startZeit;
    }

    public Date getEndZeit() {
        return endZeit;
    }

    public void setEndZeit(Date endZeit) {
        this.endZeit = endZeit;
    }

    public int getGewinn() {
        return gewinn;
    }

    public void setGewinn(int gewinn) {
        this.gewinn = gewinn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Highscoreliste)) {
            return false;
        }
        Highscoreliste other = (Highscoreliste) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ch.bbbaden.quizlb151.Highscoreliste[ id=" + id + " ]";
    }

}
