/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.quizlb151;

import java.io.Serializable;
import java.util.Random;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author monst
 */
@Named(value = "gameBean")
@SessionScoped
public class gameBean implements Serializable {

    private int balance;
    private int healthPoints;
    private String userName;
    private String difficulty;

    private String category;
    private boolean gameRunning;
    private String userGuess;
    private boolean guessRight;

    private String spinReward;
    private String secretWord;
    private Word outputGrid;

    private boolean spinDisabled;
    private boolean guessDisabled;

    private final int vowelPrice = 1000;

    private final String consonants = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ";

    public gameBean() {
        secretWord = "This is just a Test";
        outputGrid = new Word(secretWord);
        gameRunning = false;
        spinDisabled = true;
        guessDisabled = true;
        guessRight = false;
    }

    public void spin() {
        if (gameRunning) {
            spinDisabled = true;
            guessDisabled = false;
            Random random = new Random();
            int randomNum = random.nextInt(6);
            switch (randomNum) {
                case 0:
                    spinReward = "Bankrott"; //16% probability of bankrupcy
                    balance = 0;
                    gameRunning = false;
                    break;
                case 1:
                case 2:
                case 3:
                    spinReward = "500"; //16% probability of 500
                    balance += Integer.valueOf(spinReward);
                    break;
                case 4:
                    spinReward = "1000"; //16% probability of 1000
                    balance += Integer.valueOf(spinReward);
                    break;
                default:
                    spinReward = "1500"; //16% probability of 1500
                    balance += Integer.valueOf(spinReward);
                    break;
            }
        }

    }

    public void buyVowel() {
        if (balance >= vowelPrice) {
            balance -= vowelPrice;
            outputGrid.showAllVowels();
        }

    }

    public void guess() {
        if (gameRunning) {
            spinDisabled = false;
            guessDisabled = true;
            if (userGuess.length() == 1) { //Guessing only a letter
                if (consonants.contains(userGuess)) {
                    boolean letterFound = false;
                    for (Letter letter : outputGrid.getLetters()) {
                        if (Character.toUpperCase(letter.getCharacter()) == userGuess.charAt(0)) {
                            letter.setVisible(true);
                            letterFound = true;
                            guessRight = true;
                        }
                        else if (Character.toLowerCase(letter.getCharacter()) == userGuess.charAt(0)) {
                            letter.setVisible(true);
                            letterFound = true;
                            guessRight = true;
                        }
                    }
                    if (!letterFound) {
                        if (healthPoints == 1) {
                            gameRunning = false;
                        }
                        healthPoints--;
                        guessRight = false;
                    }
                }
                else {
                    System.out.println("Invalid Input: " + userGuess);
                }
            }
            else if (userGuess.length() > 1) { //Guessing the whole word
                if (secretWord.equals(userGuess)) {
                    outputGrid.setWordVisible();
                    guessRight = true;
                }
                else {
                    if (healthPoints == 1) {
                        gameRunning = false;
                    }
                    healthPoints--;
                    guessRight = false;
                }
            }
        }
    }

    public void play() {
        if (userName.length() > 0) {
            healthPoints = 3;
            balance = 0;
            spinDisabled = false;
            gameRunning = true;
            category = "TEST Animals";
            secretWord = "This is just a Test";
            outputGrid = new Word(secretWord);
        }
        else {
            gameRunning = false;
            System.out.println("Bitte gebe einen Nutzernamen an.");
        }
    }

    public boolean isGuessDisabled() {
        return guessDisabled;
    }

    public void setGuessDisabled(boolean guessDisabled) {
        this.guessDisabled = guessDisabled;
    }

    public boolean isSpinDisabled() {
        return spinDisabled;
    }

    public void setSpinDisabled(boolean spinDisabled) {
        this.spinDisabled = spinDisabled;
    }

    public Word getOutputGrid() {
        return outputGrid;
    }

    public void setOutputGrid(Word outputGrid) {
        this.outputGrid = outputGrid;
    }

    public int getVowelPrice() {
        return vowelPrice;
    }

    public String getSpinReward() {
        return spinReward;
    }

    public void setSpinReward(String spinReward) {
        this.spinReward = spinReward;
    }

    public String getSecretWord() {
        return secretWord;
    }

    public void setSecretWord(String secretWord) {
        this.secretWord = secretWord;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    public void setGameRunning(boolean gameRunning) {
        this.gameRunning = gameRunning;
    }

    public String getUserGuess() {
        return userGuess;
    }

    public void setUserGuess(String userGuess) {
        this.userGuess = userGuess;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

}
