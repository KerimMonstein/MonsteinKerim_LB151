/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.quizlb151;

import java.io.Serializable;
import static java.lang.System.out;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

/**
 *
 * @author monst
 */
@Named(value = "gameBean")
@SessionScoped
public class gameBean implements Serializable {

    private int balance;
    private int healthPoints;
    private String userName;
    private String difficulty;

    private String category;
    private boolean gameRunning;
    private String userGuess;
    private boolean guessRight;

    private String feedback;
    private String spinReward;
    private String secretWord;
    private Word outputGrid;

    private boolean spinDisabled;
    private boolean guessDisabled;

    private Date startTime;
    private Date endTime;

    private final int vowelPrice = 1000;

    private final String consonants = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ";

    public gameBean() {
        secretWord = "";
        outputGrid = new Word(secretWord);
        gameRunning = false;
        spinDisabled = true;
        guessDisabled = true;
        guessRight = false;
    }

    public void spin() {
        if (gameRunning) {
            spinDisabled = true;
            guessDisabled = false;
            feedback = "";
            Random random = new Random();
            if (5 >= random.nextInt(101)) { //5% probability of bankrupcy
                spinReward = "Bankrott";
                balance = 0;
                healthPoints = 0;
                gameRunning = false;
            }
            else {
                spinReward = String.valueOf(random.nextInt(501) + 500); //Random amount between 500 and 1000
            }

        }

    }

    public void buyVowel() {
        if (balance >= vowelPrice && !outputGrid.isVowelsVisible()) {
            balance -= vowelPrice;
            outputGrid.showAllVowels();
        }

    }

    public void guess() {
        if (gameRunning) {
            spinDisabled = false;
            guessDisabled = true;
            feedback = "";
            if (userGuess.length() == 1) { //Guessing only a letter
                if (consonants.contains(userGuess)) {
                    boolean letterFound = false;
                    for (Letter letter : outputGrid.getLetters()) {
                        if (Character.toUpperCase(letter.getCharacter()) == userGuess.charAt(0)) {
                            letter.setVisible(true);
                            letterFound = true;
                            guessRight = true;
                            feedback = "Richtig geraten!";

                        }
                        else if (Character.toLowerCase(letter.getCharacter()) == userGuess.charAt(0)) {
                            letter.setVisible(true);
                            letterFound = true;
                            guessRight = true;
                            feedback = "Richtig geraten!";
                        }
                    }
                    if (!letterFound) {
                        if (healthPoints == 1) {
                            gameRunning = false;
                        }
                        healthPoints--;
                        guessRight = false;
                        feedback = "Falsch geraten!"; 
                    }
                }
                else {
                    feedback = "Bitte geben Sie nur Konsonanten oder ganze Wörter/Phrasen ein.";
                }
            }
            else if (userGuess.length() > 1) { //Guessing the whole word
                if (secretWord.equals(userGuess)) {
                    outputGrid.setWordVisible();
                    guessRight = true;
                    feedback = "Richtig geraten!";
                }
                else {
                    if (healthPoints == 1) {
                        gameRunning = false;
                    }
                    healthPoints--;
                    guessRight = false;
                    feedback = "Falsch geraten!";
                }
            }
        }
        if (guessRight) {
            balance += Integer.valueOf(spinReward);
        }
    }

    public boolean isWordGuessed() {
        for (Letter letter : outputGrid.getLetters()) {
            if (!letter.isVisible()) {
                return false;
            }
        }
        return true;
    }

    public void play() {

        if (userName.length() > 0) {

            if (isWordGuessed() == true) {
                
            }
            else {
                balance = 0;
            }
            healthPoints = 3;
            spinReward = "";
            spinDisabled = false;
            guessDisabled = true;
            gameRunning = true;
            startTime = new Date();

            EntityManager em = Persistence.createEntityManagerFactory("ch.bbbaden_MonsteinKerim_LB151_war_1.0-SNAPSHOTPU").createEntityManager(); // Call the named query "Phrases.findAll" 
            TypedQuery< Woerter> query = em.createNamedQuery("Woerter.findByDifficulty", Woerter.class);
            query.setParameter("id_schwierigkeit", difficulty);
            List<Woerter> words = query.getResultList();

            Random rndm = new Random();
            int bounds = rndm.nextInt(words.size());

            boolean matchesDifficulty = false;
            while (!matchesDifficulty) {
                if (words.get(bounds).getIdSchwierigkeit().getSchwierigkeitsgrad().equals(difficulty)) {
                    secretWord = words.get(bounds).getWort();
                    matchesDifficulty = true;
                }
                category = words.get(bounds).getIdKategorie().getKategorie();
                outputGrid = new Word(secretWord);
            }
            System.out.println(secretWord + " DIF: " + difficulty + " DBDIF: " + words.get(bounds).getIdSchwierigkeit().getSchwierigkeitsgrad());
            em.close();
        }
        else {
            gameRunning = false;
            feedback = "Bitte gebe einen Nutzernamen an.";
        }
    }

    public void endGame() {
        gameRunning = false;
        endTime = new Date();
        feedback = "Verloren :(";

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("ch.bbbaden_MonsteinKerim_LB151_war_1.0-SNAPSHOTPU");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        UserTransaction transaction = null;
        try {
            transaction = (UserTransaction) new InitialContext().lookup("java:comp/UserTransaction");
            transaction.begin(); 
            entityManager.joinTransaction();

            //Save previous highscores
            List<Highscoreliste> previousHighscores = entityManager.createQuery("SELECT h FROM Highscoreliste h ORDER BY h.gewinn DESC, h.endZeit ASC", Highscoreliste.class).getResultList();
            
            int rank = 1;
            int prevGewinn = -1;
            for (Highscoreliste hs : previousHighscores) {
                if (hs.getGewinn() != prevGewinn) {
                    rank = hs.getRang();
                }
                hs.setRang(rank++);
                prevGewinn = hs.getGewinn();
                entityManager.merge(hs);
            }

            // Add new highscore
            Highscoreliste highscore = new Highscoreliste();
            highscore.setName(userName);
            highscore.setStartZeit(startTime);
            highscore.setEndZeit(endTime);
            highscore.setGewinn(balance);
            entityManager.persist(highscore);

            // Update ranks
            List<Highscoreliste> updatedHighscores = entityManager.createQuery("SELECT h FROM Highscoreliste h ORDER BY h.gewinn DESC, h.endZeit ASC", Highscoreliste.class)
                    .getResultList();
            rank = 1;
            for (Highscoreliste hs : updatedHighscores) {
                hs.setRang(rank++);
                entityManager.merge(hs);
            }

            // Print highscores
            System.out.println("Highscores:");
            for (Highscoreliste hs : updatedHighscores) {
                System.out.println(hs.getName() + ": " + hs.getGewinn() + " (Rang: " + hs.getRang() + ")");
            }

            transaction.commit();
        }
        catch (IllegalStateException | SecurityException | NamingException | HeuristicMixedException | HeuristicRollbackException | NotSupportedException | RollbackException | SystemException ex) {
            try {
                if (transaction != null) {
                    transaction.rollback();
                }
            }
            catch (IllegalStateException | SecurityException | SystemException e) {
                System.out.println("Transaction null oder so Rollback error hilfe");
            }
        } finally {
            entityManager.close();
            entityManagerFactory.close();
        }
    }

    public String getFeedback() {
        return feedback;
    }
    
    public boolean isGuessDisabled() {
        return guessDisabled;
    }

    public void setGuessDisabled(boolean guessDisabled) {
        this.guessDisabled = guessDisabled;
    }

    public boolean isSpinDisabled() {
        return spinDisabled;
    }

    public void setSpinDisabled(boolean spinDisabled) {
        this.spinDisabled = spinDisabled;
    }

    public Word getOutputGrid() {
        return outputGrid;
    }

    public void setOutputGrid(Word outputGrid) {
        this.outputGrid = outputGrid;
    }

    public int getVowelPrice() {
        return vowelPrice;
    }

    public String getSpinReward() {
        return spinReward;
    }

    public void setSpinReward(String spinReward) {
        this.spinReward = spinReward;
    }

    public String getSecretWord() {
        return secretWord;
    }

    public void setSecretWord(String secretWord) {
        this.secretWord = secretWord;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    public void setGameRunning(boolean gameRunning) {
        this.gameRunning = gameRunning;
    }

    public String getUserGuess() {
        return userGuess;
    }

    public void setUserGuess(String userGuess) {
        this.userGuess = userGuess;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

}
